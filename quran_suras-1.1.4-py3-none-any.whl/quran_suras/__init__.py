from .quran_suras import QuranSuras
